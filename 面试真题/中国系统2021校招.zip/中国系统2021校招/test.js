let array = new Array;
let newArray = new Array(2);
console.log('array.length',array.length)
console.log('newArray.length',newArray.length)

let one = 0.1;
let two = 0.2;
console.log('js中的“浮点数”是否相等: ',0.8-0.6)
console.log(one - two)
console.log(one++)

console.log('parseInt学习：',parseInt('12612',6))
// console.log('parseInt学习：', parse(021,8))
// 1 + - + + + - + 1  js空格无意义，这个是省略写法，省略了0
# Vue Router 4 Course Starter Files
Starter files for [Vue Router 4 for Everyone](https://vueschool.io/courses/vue-router-4-for-everyone)
